var i = 10;
while (i--) {
    console.log(i);
}