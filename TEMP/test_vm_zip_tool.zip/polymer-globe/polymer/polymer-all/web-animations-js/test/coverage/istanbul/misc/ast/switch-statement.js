var foo = '10';

switch (foo) {
    case 5:
    case 10:
        console.log('10');
        break;
    case 20:
        console.log('20');
        break;
    default:
        console.log('other');
        break;
}
