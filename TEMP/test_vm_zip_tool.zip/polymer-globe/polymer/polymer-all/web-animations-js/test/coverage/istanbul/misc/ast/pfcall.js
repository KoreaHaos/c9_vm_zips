(function () { (function() { return 1; })(); })();
