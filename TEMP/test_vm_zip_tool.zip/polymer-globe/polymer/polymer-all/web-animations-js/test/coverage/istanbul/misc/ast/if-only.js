if (20 > 10) console.log('Yay!');
