var x = 2, output;
output = x < 5 ?
   (function() { return 42; }())
 : 15;
