function test() {
    /*
     * this is comment
     */
    var i = 20;
}
