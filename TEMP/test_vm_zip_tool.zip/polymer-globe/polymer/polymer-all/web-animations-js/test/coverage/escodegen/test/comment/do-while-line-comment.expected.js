do {
}    // LINE
while (true);
