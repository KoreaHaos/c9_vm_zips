 if (1 === 2) { console.log('foo'); }
