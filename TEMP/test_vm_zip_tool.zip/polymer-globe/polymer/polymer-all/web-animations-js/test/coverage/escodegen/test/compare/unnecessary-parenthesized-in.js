var i = 0 in ['test'];
