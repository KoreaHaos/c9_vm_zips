if (process.argv[2])
    if (process.argv[3])
        console.log('TT');

