({ t: t }) = obj;
({
    t: { C: C }
}) = obj;
({ a, b, c }) = obj;
