var foo = { bar: { baz: [ 1, 2 ] } };
foo.bar.baz[0] = 3;

