new (a()).b();
new a().b();
new (a()).b();
new (a())();
new new a(a)();
new new a()(a);
new a().test;
new a().test;
new (a()).test();
