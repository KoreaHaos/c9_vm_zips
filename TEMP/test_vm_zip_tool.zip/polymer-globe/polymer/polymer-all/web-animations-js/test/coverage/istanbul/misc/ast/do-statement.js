var i = 5;
do 
	i--;
 while (i > 0);

