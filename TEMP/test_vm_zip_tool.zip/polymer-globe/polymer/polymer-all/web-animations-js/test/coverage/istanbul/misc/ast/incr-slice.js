var foo = { lineMap: { 1: 0 }}, bar = {
    2: 0
};
foo.lineMap[1]++;
