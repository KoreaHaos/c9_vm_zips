var foo = { a: 10, b: 20 };
for (var k in foo) console.log(k + '=' + foo[k]);

