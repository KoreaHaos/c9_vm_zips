1.1.valueOf();
1e+300.valueOf();
