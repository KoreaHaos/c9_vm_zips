module.exports = function () { return 32; };

