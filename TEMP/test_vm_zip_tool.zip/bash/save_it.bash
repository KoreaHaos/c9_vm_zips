git add --all :/
git commit -m 'Commited_with_save_it.bash_script.'
git push --all
